package beast.core;

/**
 * @author Andrew Rambaut
 * @version $Id$
 */
public interface Evaluator {
    double evaluate();
}
